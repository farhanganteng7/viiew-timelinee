# Auto Views Stories Target v1
Auto Views Stories Target v1

![fix](https://user-images.githubusercontent.com/59155826/83029317-c45bb000-a05c-11ea-84f0-3be9e3b9ef54.PNG)

## Default usage
	$ git clone https://github.com/sandrocods/instagram-views/
	$ cd instagram-views
	$ php run.php

## Update by me
added session store

Session Live             |  Session Die
:-------------------------:|:-------------------------:
![session live](https://telegra.ph/file/b062aeec50bd54c990d9c.png)  |  ![session die](https://telegra.ph/file/5c290fc86cfa3b376ca85.png)
